The readme files for each each phase and Tasks is available under the respective directories:

Phase1:
  Task1 - README.txt
  Task2 - README.txt
  Task3 - README.txt

Phase2:
SnippetGeneration - README.txt

Phase3:
   README.txt

ExtraCredit:
 README.txt


To run the scripts you need to have python3 installed and the following dependencies needs to be imported:

import glob
import operator
import os
import re
import shutil
import dominate
from collections import Counter
from math import log