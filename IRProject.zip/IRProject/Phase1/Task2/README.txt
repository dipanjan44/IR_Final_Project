Task2

1. Folder : input_files
*This folder contains the input files for the Task2

2. Folder : output
*This folder contains the output files for the Task2

3. PSEUDORELEVANCE_BM25.py

*This file takes the cacm corpus,cacm.rel.text,common_words.txt and cacm.query as input produces an output of the top 100 documents obtained after the query expansion for each query.
*Change the path of the 'path' folder to the location where the clean corpus is present.
*Change the path of the 'folder' on line 18 folder to the location where the 'cacm.rel.text' is present.
*Change the path of the 'folder' on line 119 folder to the location where the 'common_words.txt' is present.
*Change the path of the 'query_list' on line 269 folder to the location where the 'cacm.query' is present.
*Change the path of the 'folder' on line 272 folder to the location where the result needs to be stored.

*Run the main function by right clicking inside the file PSEUDORELEVANCE_BM25.py and clicking on ‘Run’
