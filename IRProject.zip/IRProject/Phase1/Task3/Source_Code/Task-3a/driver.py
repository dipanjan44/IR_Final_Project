import stopped_corpus
import BM25
import TF_IDF
import QUERY_LIKELIHOOD

if __name__ == '__main__':
    # stopped_corpus.main()
    BM25.main()
    #TF_IDF.main()
    QUERY_LIKELIHOOD.main()
