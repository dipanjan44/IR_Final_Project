PHASE 1 : TASK3

FOLDER STRUCTURE:
1.Source Code Files are in Source_Code
	-- Task 3a source code is in Source_Code/Task-3a
	-- Task 3b source code is in Source_Code/Task-3b
2. Input files for stopping and stemming are in stopped_files and stemmed_files respectively
3. Output files are generated in output directory


To run,
1. Unzip stopped_files.zip and stemmed_files.zip
2. Run 'python driver.py' in both source code directories to run all the retrieval models on stemmed and stopped    versions of the corpus.

