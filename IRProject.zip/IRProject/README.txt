The readme files for each each phase and Tasks is available under the respective directories:

Phase1:
  Task1 - README.txt
  Task2 - README.txt
  Task3 - README.txt

Phase2:
SnippetGeneration - README.txt

Phase3:
   README.txt

ExtraCredit:
 README.txt